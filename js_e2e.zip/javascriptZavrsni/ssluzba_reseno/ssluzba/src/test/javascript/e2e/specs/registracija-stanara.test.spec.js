var LoginPageKTS = require('../pages/global.KTS/login.pageKTS.js');
var MenuPageKTS = require('../pages/global.KTS/menu.pageKTS.js');
var HomePageKTS = require('../pages/global.KTS/home.pageKTS.js');
var StanarCreatePage = require('../pages/stanari.KTS/stanari-create.page.js');
var utils = require('../pages/utils.js');
var baseUrl = 'http://localhost:8080/logovanje';

describe('Registracija stanara od strane admina', function () {
    var loginPageKTS,
        menuPageKTS,
        homePageKTS,
        stanarCreatePage;

    beforeAll(function () {
        browser.ignoreSynchronization = true;
        loginPageKTS = new LoginPageKTS();
        menuPageKTS = new MenuPageKTS();
        homePageKTS = new HomePageKTS();
        stanarCreatePage = new StanarCreatePage();
        browser.get('/');
        // expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });

    it('should succesfully register stanara', function () {
        loginPageKTS.login('admin@gmail.com', 'Bar5slova');
        //expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/pocetna');

        expect(menuPageKTS.pocetna.isDisplayed()).toBe(true);
        // expect(menuPageKTS.stanari.isDisplayed()).toBe(true);
        menuPageKTS.stanari.click();
        //expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/stanari');
        expect(stanarCreatePage.formRegistracijaStanara.isDisplayed()).toBe(true);
        stanarCreatePage.createStanar('maricaja2@gmail.com', 'Bar5slova', 'Mashja', 'Makrtic');
        expect(stanarCreatePage.uspesnaRegistracijaPoruka.isDisplayed()).toBe(true);
        menuPageKTS.izlogujteSeBtn.click();
        //expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });
    
});