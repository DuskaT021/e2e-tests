var ZgradaCreatePage = function () { };
var utils = require('../utils.js');

ZgradaCreatePage.prototype = Object.create({}, {

    prozorDodavanjeZgrade: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//form'), 10000);
        }
    },
    dodavanjeBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//li/button/b[contains(text(),"Dodavanje")]'), 10000);
        }
    },
    pregledBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//li/button/b[contains(text(),'Pregled')]"), 10000);
        }
    },
    mesto: {
        get: function () {
            return utils.waitForElementPresence(by.id('mesto'), 10000);
        },
        set: function (value) {
            return this.mesto.clear().sendKeys(value);
        }
    },
    ulica: {
        get: function () {
            return utils.waitForElementPresence(by.id('ulica'), 10000);
        },
        set: function (value) {
            return this.ulica.clear().sendKeys(value);
        }
    },
    broj: {
        get: function () {
            return utils.waitForElementPresence(by.id('broj'), 10000);
        },
        set: function (value) {
            return this.broj.clear().sendKeys(value);
        }
    },
    brojStanova: {
        get: function () {
            return utils.waitForElementPresence();
        }
    },

    createZgrada: {
        value: function (mesto, ulica, broj, brojStanova) {
            this.mesto = mesto;
            this.ulica = ulica;
            this.broj = broj;
            this.brojStanova;
        }
    },
    submitDodajteBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//div//button[@type="submit"]'), 10000);

        }
    },
    resetujteBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div/button[@type=\"button\"]", 10000));
        }
    },
    dodataZgradaPoruka: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[@aria-label=\"Uspesno ste dodali zgradu!\"]"), 10000);
        }
    },
    vecPostojiZgradaMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//div[@aria-label]'), 10000);
        }
    },
    emptyMestoMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[1]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 10000);
        }
    },
    emptyUlicaMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[2]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 10000);
        }
    },
    emptyBrojMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[3]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 10000);
        }
    },
    emptyBrojStanovaMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[3]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 10000);

        }

    },
    nulaBrojMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[3]/div/div[contains(text(),'Broj mora biti pozitivan!')]"), 10000);
        }
    },
    nulaBrojStanovaMessage: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//div[4]/div/div[contains(text(),'Broj mora biti pozitivan!')]"), 10000);
        }
    }




});
module.exports = ZgradaCreatePage;