var StanariListPage = function () { };
var utils = require('../utils.js');

StanariListPage.prototype = Object.create({}, {

    pregledBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//button/b[contains(text(),'Pregled')]"),10000);
        }
    },

    pretragaBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//button[contains(text(),'Pretraga')]"),10000);
        }
    },

    dropDownPrikazi: {
        get: function () {
            return utils.waitForElementPresence(by.id('prikaz'), 10000);

        }
    },
    inputUnesite: {
        get: function () {
            return utils.waitForElementPresence(by.id('filter'), 10000);
        },
        set: function (value) {
            return this.inputUnesite.clear().sendKeys(value);
        }
    },
    pretragaStanara: {
        value: function (imePrezimeString) {
            this.inputUnesite = imePrezimeString;
            this.pretragaBtn.click();
        }
    },
    vlasnikStanariBtn: {
        get: function () {
            return utils.waitForElementPresence(by.xpath("//a[contains(text(),'Vlasnik i stanari')]"), 10000);
        }

    },
    nePostojiStanarPoruka: {
        get: function () {
            return utils.waitForElementPresence(by.tagName('h2'), 10000);
        }
    },
    tabelaStanariPregled: {
        get: function () {
            return utils.waitForElementPresence(by.tagName('table'), 10000);
        }
    },
    tableRows: {
        get: function () {
            return element.all(by.tagName('tr'));
        }
    },
    getStanarRedByImePrezime: {
        value: function (imePrezimeString) {
            var el = this.tabelaStanariPregled.element(by.xpath('//*[contains(text(),"' + imePrezimeString + '")]/../..'));
            return new StanarRow(el);
        }
    }

});
module.exports = StanariListPage;