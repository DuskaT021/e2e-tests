var MenuPageKTS = function() {};
var utils = require('../utils.js');

MenuPageKTS.prototype = Object.create({},{
    pregledDugme:{
        get: function() {
            return utils.waitForElementPresence(by.xpath('//button/b[contains(text(),"Pregled")]'), 10000);
        }
    },
    dodavanjeDugme:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//button/b[contains(text(),"Dodavanje")]'),10000);
        }
    },

    pocetna:{
        get: function(){
            return utils.waitForElementPresence(by.linkText('Pocetna'),10000);
        }

    },
    zgrade:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//h4//li/a[@href="/zgrade"]'),10000);
        }
    },
    stanari:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//ul[@id="opcije"]/li/a[@href="/stanari"]'),10000);
        }
    },
    // proveriti selektor
    institucije:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//h4//li/a[@href="/institucije"]'),10000);
        }
    },
    //proveriti selektor
    firme:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//h4//li/a[@href="/firme"]'),10000);
        }
    },

    labelMail:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//label[@class="nav-link active"]'),10000);
        }
    },
    izlogujteSeBtn:{
        get: function(){
            return utils.waitForElementPresence(by.className('btn-secondary'),10000);
        }
    },

});
module.exports = MenuPageKTS;
