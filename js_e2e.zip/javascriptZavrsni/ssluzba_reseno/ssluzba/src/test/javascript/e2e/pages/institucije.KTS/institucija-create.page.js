var InstitucijaCreatePage = function (){};
var utils = require('../utils.js');

InstitucijaCreatePage.prototype = Object.create({}, {

    registrujteBtn: {
        get : function(){
            return utils.waitForElementPresence(by.xpath("//button[@type='submit']"),10000);
        }
    },
    emailPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("email"), 10000);
        },
        set: function (value) {
            return this.emailPolje.clear().sendKeys(value);
        }
    },
    lozinkaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("lozinka"), 10000);
        },
        set: function (value) {
            return this.lozinkaPolje.clear().sendKeys(value);
        }

    },
    nazivPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("naziv"), 10000);
        },
        set: function (value) {
            return this.nazivPolje.clear().sendKeys(value);
        }

    },
    mestoPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("mesto"), 10000);
        },
        set: function (value) {
            return this.mestoPolje.clear().sendKeys(value);
        }
    },
    ulicaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("ulica"), 10000);
        },
        set: function (value) {
            return this.ulicaPolje.clear().sendKeys(value);
        }

    },
    brojPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("broj"), 10000);
        },
        set: function (value) {
            return this.brojPolje.clear().sendKeys(value);
        }

    },
    brojTelefonaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.id("brojTelefona"), 10000);
        },
        set: function (value) {
            return this.brojTelefonaPolje.clear().sendKeys(value);
        }

    },
    porukaUspesnoRegistrovanje:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//div[@aria-label]"),10000);
        }
    },
    registrationForm:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//form"),10000);
        }
    }



    });
    module.exports =  InstitucijaCreatePage;