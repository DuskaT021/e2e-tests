var LoginPageKTS = require('../pages/global.KTS/login.pageKTS.js');
var MenuPageKTS = require('../pages/global.KTS/menu.pageKTS.js');
var HomePageKTS = require('../pages/global.KTS/home.pageKTS.js')
var utils = require('../pages/utils.js');
var baseUrl = 'http://localhost:8080/logovanje';

describe('Validno logovanje kao admin', function () {
    var loginPageKTS,
        menuPageKTS,
        homePageKTS;

    beforeAll(function () {
        browser.ignoreSynchronization = true;
        loginPageKTS = new LoginPageKTS();
        menuPageKTS = new MenuPageKTS();
        homePageKTS = new HomePageKTS();
        browser.get('/');
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });
    it('should successfully log in as "admin"', function () {
       
       //expect(loginPageKTS.UlogujteSeBtn.isDisplayed().toBe(true));
        loginPageKTS.login('admin@gmail.com', 'Bar5slova');
       // expect(loginPageKTS.ulogujteSeBtn.isDisplayed().toBe(true));
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/pocetna');
    });
    it('should log out',function(){
        //expect(menuPageKTS.labelMail.isDiplayed().toBe(true));
        expect(menuPageKTS.izlogujteSeBtn.isPresent()).toBe(true);
        menuPageKTS.izlogujteSeBtn.click();
        expect(browser.getCurrentUrl()).toEqual('http://localhost:8080/logovanje');
    });

    });