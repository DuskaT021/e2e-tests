
var StanarCreatePage = function () { };
var utils = require('../utils.js');

StanarCreatePage.prototype = Object.create({}, {

    formRegistracijaStanara: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//div/form'), 10000);
        }

    },
    emailPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//div/input[@id="email"]'), 10000);
        },
        set: function (value) {
            return this.emailPolje.clear().sendKeys(value);
        }
    },
    lozinkaPolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="lozinka"]'), 10000);
        },
        set: function (value) {
            return this.lozinkaPolje.clear().sendKeys(value);
        }

    },
    imePolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="ime"]'), 10000);
        },
        set: function (value) {
            return this.imePolje.clear().sendKeys(value);
        }
    },
    prezimePolje: {
        get: function () {
            return utils.waitForElementPresence(by.xpath('//input[@id="prezime"]'), 10000);

        },
        set: function (value) {
            return this.prezimePolje.clear().sendKeys(value);
        }

    },
    
    registrujteBtn: {
        get : function(){
            return utils.waitForElementPresence(by.xpath("//button[contains(text(),'Registrujte')]"),10000);
        }
    },
    createStanar:{
        value: function(emailString,lozinkaString,imeString,prezimeString){
            this.emailPolje = emailString;
            this.lozinkaPolje = lozinkaString;
            this.imePolje = imeString;
            this.prezimePolje = prezimeString;
            this.registrujteBtn.click();
        }
    },

    disabledRegistrujteBtn:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//div/div/button[@disabled]"),10000);
        }

    },
    resetujteBtn:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//button[contains(text(),'Resetujte')]"),10000);
        }
    },
    uspesnaRegistracijaPoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//div[@role='alertdialog']"),10000);
        }
    },
    zauzetEmailPoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//div[@aria-live="polite"]'),10000);
        }
    },
    praznoEmailPoljePoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//div[1]/div/div[@class="invalid-feedback"]'),10000);
        }
    },
    praznoLozinkaPoljePoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//div[2]/div/div[@class="invalid-feedback"]'),10000);
        }
    },
    praznoImePoljePoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//div[3]/div/div[@class="invalid-feedback"]'),10000);
        }
    },
    praznoPrezimePoljePoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath('//div[4]/div/div[@class="invalid-feedback"]'),10000);
        }
    },
    neispravanEmailPoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//form//div[contains(text(),'Neispravna email adresa!')]"),10000);
        }
    },
    neispravnaLozinkaPoruka:{
        get: function(){
            return utils.waitForElementPresence(by.xpath("//form//div[contains(text(),'Neispravna lozinka!')]"),10000);
        }
    }

});
module.exports = StanarCreatePage;