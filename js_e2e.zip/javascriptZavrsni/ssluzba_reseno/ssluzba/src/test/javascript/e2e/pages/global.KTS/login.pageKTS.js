
var LoginPageKTS = function() {};
var utils = require('../utils.js');

LoginPageKTS.prototype = Object.create({},{

email:{
    get: function(){
        return utils.waitForElementPresence(by.id('email'),10000);
    },
    set: function(value){
    this.email.clear();
    this.email.sendKeys(value);
    }
},
lozinka: {
    get: function() {
        return utils.waitForElementPresence(by.id('lozinka'), 10000);
    },
    set: function(value) {
        this.lozinka.clear();
        this.lozinka.sendKeys(value);
    }
},

loginForma:{
    get: function(){
        return utils.waitForElementPresence(by.name('loginForm'),10000);
    }
},

ulogujteSeBtn: {
    get: function() {
        return utils.waitForElementPresence(by.className('btn-primary'), 10000);
    }
},
navigateToPage: {
    value: function() {
        browser.get('http://localhost:8080/logovanje');
        browser.wait(function() {
            return browser.getCurrentUrl().then(function(url) {
                return url === 'http://localhost:8080/logovanje';
            });
        }, 5000)
    }
},
login: {
    value: function(emailString, lozinkaString) {
        this.email = emailString;
        this.lozinka = lozinkaString;
        this.ulogujteSeBtn.click();
    }
}

});
module.exports = LoginPageKTS;