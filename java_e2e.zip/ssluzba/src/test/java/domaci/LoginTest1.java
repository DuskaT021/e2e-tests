package domaci;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.ssluzba.pages.global.HomePage1;
import rs.ac.uns.testdevelopment.ssluzba.pages.global.LoginPage;
import rs.ac.uns.testdevelopment.ssluzba.pages.global.LoginPage1;
import rs.ac.uns.testdevelopment.ssluzba.pages.global.MenuPage1;

public class LoginTest1 {
	private WebDriver driver;
	private LoginPage1 loginPage1;
	private HomePage1 homePage1;
	private MenuPage1 menuPage1;
	private String baseUrl;

@BeforeSuite
public void setupSelenium() {
	System.setProperty("webdriver.gecko.driver", "geckodriver");
	driver =new FirefoxDriver();
	baseUrl = "http://localhost:8080/#/";
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	driver.navigate().to(baseUrl);
	setupPages();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
public void setupPages (){
	loginPage1 =new LoginPage1(driver);
	homePage1= new HomePage1(driver);
	menuPage1 = new MenuPage1(driver);
}
@Test
public void login() {
	menuPage1.getAccountMenu().click();
	assertEquals(true, menuPage1.getSignUp().isDisplayed());
	menuPage1.getSignUp().click();
	
}

@AfterSuite
public void closeSelenium(){
	driver.quit();

}
	
}
