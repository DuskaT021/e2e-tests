package domaci;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.ssluzba.pages.global.HomePage;
import rs.ac.uns.testdevelopment.ssluzba.pages.global.LoginPage;
import rs.ac.uns.testdevelopment.ssluzba.pages.global.MenuPage;

public class LoginTest {
	private WebDriver driver;
	private LoginPage loginPage;
	private MenuPage menuPage;
	private HomePage homePage;
	private String baseUrl;
	
	
	@BeforeSuite
	public void setupSelenium(){
		System.setProperty("webdriver.gecko.driver","geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/#/";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		System.out.println("Izvrsen je beforeSuite");
		
	}
	
	public void setupPages(){
		loginPage = new LoginPage(driver);
		menuPage = new MenuPage(driver);
		homePage = new HomePage(driver);
		System.out.println("Inicijalizacija objekata global pages");
	}
	@Test
	public void login(){
		menuPage.getAccountMenu().click();
		assertEquals(true, menuPage.getSignUp().isDisplayed());
		menuPage.getSignUp().click();
		loginPage.login("admin", "admin");
		String expectedMessage = "You are logged in as user \"admin\".";
		assertEquals(expectedMessage, homePage.getLoginConfirmationText());
		System.out.println("Izvrsen je login");
	}
	
	 
	@Test
	public void logout(){
		menuPage.getAccountMenu().click();
		menuPage.getLogOut().click();
		assertTrue(homePage.getInitialMessage());
		System.out.println("Izvrsen je logout!");
		
	}
	@AfterSuite
	public void closeSelenium(){
		driver.quit();
		
	}
	
	
	
	
	
	
	
	

}
