package testovi.login;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;

public class LoginTestStanarValid {

	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to(baseUrl);
		setupPages();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);

	}

	// POZITIVAN TEST
	@Test
	public void login() {
		assertTrue(loginPageKTS.getLoginForm().isDisplayed());
		assertTrue(loginPageKTS.getUlogujteSeBtn().isDisplayed());
		loginPageKTS.login("marko@gmail.com", "Bar5slova");

	}

	@AfterSuite
	public void logout() {
		menuPageKTS.getIzlogujteSeBtn().click();

	}

	public void closeSelenium() {
		driver.quit();

	}
}
