package testovi.admin.institucije;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.institucije.InstitucijaCreatePage;
import rs.ac.uns.testdevelopment.KTS.pages.institucije.InstitucijaPregledPage;

public class DodavanjeInstitucijePolicijaTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private InstitucijaCreatePage institucijaCreatePage;
	private InstitucijaPregledPage institucijaPregledPage;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		institucijaCreatePage = new InstitucijaCreatePage(driver);
		institucijaPregledPage = new InstitucijaPregledPage(driver);

	}
	public void login(){
		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	//POZITIVAN TEST Dodavanje institucije Policija
	@Test
	public void idiNaStranicuInstitucije(){
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getInstitucije().click();
		assertTrue(institucijaCreatePage.getRegistrationForm().isDisplayed());
		institucijaCreatePage.createInstitucija("policija@gmail.com", "Bar8slova", "Policija", "Novi Sad", "Cara Lazara", "45", "1122334455");
		institucijaCreatePage.getRegistrujteBtn().click();
		assertTrue(institucijaCreatePage.getPorukaUspesnoRegistrovanje().isDisplayed());
		
		
	}
	@Test
	public void pregledDodateInstitucije(){
		assertTrue(menuPageKTS.getPregledDugme().isDisplayed());
		menuPageKTS.getPregledDugme().click();
		WebElement institucijaRow = institucijaPregledPage.getInstitucijaRedByEmail("policija@gmail.com");
		String dataRow = institucijaRow.getText();
		assertTrue(dataRow.contains("Policija (policija@gmail.com)"));
	}
	@AfterSuite
	public void logout(){
		menuPageKTS.getIzlogujteSeBtn().click();
		closeSelenium();	
	}
		public void closeSelenium() {
			driver.quit();
		}


}
