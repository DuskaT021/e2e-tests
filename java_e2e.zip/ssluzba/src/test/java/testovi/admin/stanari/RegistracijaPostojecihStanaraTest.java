package testovi.admin.stanari;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.stanari.StanariCreatePage;

public class RegistracijaPostojecihStanaraTest {
//Negativan test
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private StanariCreatePage stanariCreatePage;
	private String baseUrl;
	
	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}
	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		stanariCreatePage = new StanariCreatePage(driver);
	}

	public void login() {

		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	@BeforeTest
	public void idiNaStranicuStanari() {
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		assertTrue(menuPageKTS.getStanari().isDisplayed());
		menuPageKTS.getStanari().click();
		stanariCreatePage.getFormRegistracijaStanara().isDisplayed();
		stanariCreatePage.getEmailPolje().isDisplayed();
		stanariCreatePage.getLozinkaPolje().isDisplayed();
		stanariCreatePage.getImePolje().isDisplayed();
		stanariCreatePage.getPrezimePolje().isDisplayed();
	}
	//Negativan test, koji prolazi
	@Test
	public void dodavanjePostojecegStanara(){
		stanariCreatePage.createStanari("mima@gmail.com", "Bar5slova", "Sima", "Simic");
		stanariCreatePage.getRegistrujteBtn().submit();
		assertTrue(stanariCreatePage.getUspesnaRegistracijaPoruka().isDisplayed());
		stanariCreatePage.getResetujteBtn().click();
		stanariCreatePage.createStanari("mima@gmail.com", "Bar5slova", "Sima", "Simic");
		stanariCreatePage.getRegistrujteBtn().submit();
		assertTrue(stanariCreatePage.getZauzetEmailPoruka().isDisplayed());
	}
	@AfterTest
	public void logout() {
		menuPageKTS.getIzlogujteSeBtn().click();
		
	}

	@AfterSuite

	public void closeSelenium() {
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
