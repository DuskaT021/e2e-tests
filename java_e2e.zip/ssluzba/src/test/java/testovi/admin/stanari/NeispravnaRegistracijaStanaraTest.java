package testovi.admin.stanari;


import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.stanari.StanariCreatePage;

public class NeispravnaRegistracijaStanaraTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private StanariCreatePage stanariCreatePage;
	private String baseUrl;
	
	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}
	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		stanariCreatePage = new StanariCreatePage(driver);
	}

	public void login() {
		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}

	@BeforeTest
	public void idiNaStranicuStanari() {
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getStanari().isDisplayed();
		menuPageKTS.getStanari().click();

	}
	//Negativan test, nevalidan email i lozinka, 
	@Test
	public void neispravnaRegistracijaStanara(){
		stanariCreatePage.createStanari("admin","sdhgfh","Joja","Jojic");
		//assertFalse(stanariCreatePage.getRegistrujteBtn().isEnabled());
		assertTrue(stanariCreatePage.getNeispravanEmailPoruka().isDisplayed());
		assertTrue(stanariCreatePage.getNeispravnaLozinkaPoruka().isDisplayed());
	}
	@AfterTest
	public void logout() {
		menuPageKTS.getIzlogujteSeBtn().click();
	}

	@AfterSuite
	public void closeSelenium() {
		driver.quit();
	}
	
}
