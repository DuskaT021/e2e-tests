package testovi.admin.stanari;

public class PostaviStanaraZaPredsednikaTest {

}
