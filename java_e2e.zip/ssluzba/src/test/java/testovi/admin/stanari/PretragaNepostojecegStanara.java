package testovi.admin.stanari;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.stanari.StanariPregledPage;

public class PretragaNepostojecegStanara {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private StanariPregledPage stanariPregledPage;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		stanariPregledPage = new StanariPregledPage(driver);

	}

	public void login() {
		loginPageKTS.login("admin@gmail.com", "Bar5slova");

	}
	@BeforeTest
	public void idiNaStranicuStanari(){
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getStanari().isDisplayed();
		menuPageKTS.getStanari().click();
	}

	//Negativan test, koji prolazi posto se pojavljuje ocekivana poruka
	@Test
	public void pretragaStanaraSaNevalidnimPodacima() {
		stanariPregledPage.getPregledBtn().click();
		stanariPregledPage.getPrikaz().selectByValue("50");
		stanariPregledPage.pretragaStanara("ghdfhs gfhggjh");
		assertTrue(stanariPregledPage.getNePostojiStanarPoruka().isDisplayed());
		assertEquals(stanariPregledPage.getNePostojiStanarPoruka().getText(),"Nijedan stanar sa trazenim kriterijumom nije prondajen!");
		
	}
	@AfterTest
	public void logout(){
		menuPageKTS.getIzlogujteSeBtn().click();
		
	}
	
	
	@AfterSuite
	public void closeSelenium() {
		driver.quit();
	}
	
	
	
	
	
	

}
