package testovi.admin.stanari;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaCreationPage;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaPregledPage;

public class UklanjanjePredsednikaTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradaCreationPage zgradaCreationPage;
	private ZgradaPregledPage zgradaPregledPage;
	private String baseUrl;

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();
		idiNaStranicuZgrade();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradaPregledPage = new ZgradaPregledPage(driver);
		zgradaCreationPage = new ZgradaCreationPage(driver);
	}

	public void login() {

		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}

	// @BeforeTest
	public void idiNaStranicuZgrade() {
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getZgrade().isDisplayed();
		menuPageKTS.getZgrade().click();
		assertTrue(zgradaCreationPage.getProzorDodavanjeZgrade().isDisplayed());
		zgradaCreationPage.getMesto().isDisplayed();
		zgradaCreationPage.getUlica().isDisplayed();
		zgradaCreationPage.getBroj().isDisplayed();
		zgradaCreationPage.getBrojStanova().isDisplayed();
		zgradaCreationPage.getSubmitDodajteBtn().isDisplayed();
		zgradaCreationPage.getResetujteBtn().isDisplayed();

	}
	@Test(priority=1)
	public void klikNaZgradaUTabeli() {
		zgradaCreationPage.getPregledBtn().click();
		zgradaPregledPage.getRedZaPretragu().isDisplayed();
		assertTrue(zgradaPregledPage.getSelectPrikazi().isDisplayed());
		zgradaPregledPage.getPrikaz().selectByValue("50");
		zgradaPregledPage.isZgradaInTabela("Isidore Sekulic 2, Novi Sad");
		zgradaPregledPage.viewZgradaByAdresa("Isidore Sekulic 2, Novi Sad");
		zgradaPregledPage.getHoverTabelaZgrada().isDisplayed();
		zgradaPregledPage.viewVlasnikStanaZgrade("3");
		assertTrue(zgradaPregledPage.getTabelaKorisnici().isDisplayed());
		zgradaPregledPage.pritisniDodajUstanareBtn("Nikola Nikolic");
		assertEquals(zgradaPregledPage.getPorukaDodatStanarUstan().getText(), "Uspesno ste dodali stanara!");
	}
	@Test(priority=2)
	public void postaviZaPredsednika(){
		zgradaPregledPage.getTabelaStanari().isDisplayed();
		zgradaPregledPage.pritisniPostaviZaPredsednikaBtn("Nikola Nikolic");
		assertEquals(zgradaPregledPage.getPorukaUspesnoPostavljenPredsednik().getText(),"Uspesno ste postavili predsednika zgrade!");
	}
	@Test(priority=3)
	public void ukloniZaPredsednika(){
		zgradaPregledPage.ukloniStanaraBtn("Nikola Nikolic");
		assertEquals(zgradaPregledPage.getPorukaUklonjenStanar().getText(),"Uspesno ste uklonili stanara!");
		
	}

	// @AfterTest
	public void logout() {
		menuPageKTS.getIzlogujteSeBtn().click();

	}

	@AfterSuite

	public void closeSelenium() {
		logout();
		driver.quit();
	}

}
