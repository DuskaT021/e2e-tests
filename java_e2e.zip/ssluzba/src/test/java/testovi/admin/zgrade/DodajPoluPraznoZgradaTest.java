package testovi.admin.zgrade;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaCreationPage;

public class DodajPoluPraznoZgradaTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradaCreationPage zgradaCreationPage;
	private String baseUrl;
	
	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();
		idiNaStranicuZgrade();

	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradaCreationPage = new ZgradaCreationPage(driver);
	}

	public void login() {
		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	
	public void idiNaStranicuZgrade(){
		menuPageKTS.getPocetna().isDisplayed();
		
		menuPageKTS.getNavBar().isDisplayed();
		
		menuPageKTS.getZgrade().isDisplayed();
		menuPageKTS.getZgrade().click();
		zgradaCreationPage.getProzorDodavanjeZgrade().isDisplayed();
		//zgradaCreationPage.getMesto().isDisplayed();
		//zgradaCreationPage.getUlica().isDisplayed();
		//zgradaCreationPage.getBroj().isDisplayed();
		//zgradaCreationPage.getBrojStanova().isDisplayed();
		//zgradaCreationPage.getSubmitDodajteBtn().isDisplayed();*/
		//zgradaCreationPage.getResetujteBtn().isDisplayed();
		
		}
	@Test
	public void dodajPoluPraznoZgrada(){
		zgradaCreationPage.createPraznaZgrada("Novi Sad", "Micurinova", "", "");
		assertTrue(zgradaCreationPage.getEmptyBrojMessage().isDisplayed());
		
		assertTrue(zgradaCreationPage.getResetujteBtn().isDisplayed());
		zgradaCreationPage.getResetujteBtn().click();
		
	}
	public void logout(){
		menuPageKTS.getIzlogujteSeBtn().click();
		//System.out.println("Izvrsen je logout");
	}
	
	
	@AfterSuite
	
	public void closeSelenium() {
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
