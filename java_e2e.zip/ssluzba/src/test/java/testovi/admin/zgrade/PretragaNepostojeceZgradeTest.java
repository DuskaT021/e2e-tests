package testovi.admin.zgrade;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaCreationPage;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaPregledPage;

public class PretragaNepostojeceZgradeTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradaCreationPage zgradaCreationPage;
	private ZgradaPregledPage zgradaPregledPage;
	private String baseUrl;
	
	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();
		
	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradaCreationPage = new ZgradaCreationPage(driver);
		zgradaPregledPage = new ZgradaPregledPage(driver);
		
	}
	
	public void login() {
		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	@BeforeTest
	public void idiNaStranicuZgrade(){
		menuPageKTS.getPocetna().isDisplayed();
		menuPageKTS.getNavBar().isDisplayed();
		menuPageKTS.getZgrade().isDisplayed();
		menuPageKTS.getZgrade().click();
		}
	
	//Negativan test, prolazi, prikaz poruke da ne postoji zgrada!
	@Test
	public void pretragaSaNevalidnimPodacima(){
		zgradaCreationPage.getPregledBtn().click();
		zgradaPregledPage.getPretragaBtn().isDisplayed();
		zgradaPregledPage.pretragaZgrade("vbdfsh4124//*", "@#@@/*/GFhf");
		//zgradaPregledPage.getInputUlicaBroj().isDisplayed();
		//zgradaPregledPage.getInputMesto().isDisplayed();
		assertEquals(zgradaPregledPage.getNePostojiZgradaPoruka().getText(),"Nijedna zgrada sa trazenim kriterijumima nije prondajena!");
		
	}
	
	@AfterTest
	public void logout(){
		menuPageKTS.getIzlogujteSeBtn().click();
		
	}
	
	
	@AfterSuite
	public void closeSelenium() {
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
