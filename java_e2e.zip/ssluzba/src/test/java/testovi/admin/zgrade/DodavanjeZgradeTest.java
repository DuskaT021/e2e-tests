package testovi.admin.zgrade;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import rs.ac.uns.testdevelopment.KTS.pages.global.LoginPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.global.MenuPageKTS;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaCreationPage;
import rs.ac.uns.testdevelopment.KTS.pages.zgrade.ZgradaPregledPage;

public class DodavanjeZgradeTest {
	private WebDriver driver;
	private LoginPageKTS loginPageKTS;
	private MenuPageKTS menuPageKTS;
	private ZgradaCreationPage zgradaCreationPage;
	private ZgradaPregledPage zgradaPregledPage;
	private String baseUrl;
	

	@BeforeSuite
	public void setupSelenium() {
		System.setProperty("webdriver.gecko.driver", "geckodriver");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/logovanje";
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		setupPages();
		login();
		idiNaStranicuZgrade();
		
	}

	public void setupPages() {
		loginPageKTS = new LoginPageKTS(driver);
		menuPageKTS = new MenuPageKTS(driver);
		zgradaPregledPage = new ZgradaPregledPage(driver);
		zgradaCreationPage = new ZgradaCreationPage(driver);
	}
	
	
	public void login() {
		
		loginPageKTS.login("admin@gmail.com", "Bar5slova");
	}
	
	
	//@BeforeTest
	public void idiNaStranicuZgrade(){
		menuPageKTS.getPocetna().isDisplayed();	
		menuPageKTS.getNavBar().isDisplayed();		
		menuPageKTS.getZgrade().isDisplayed();
		menuPageKTS.getZgrade().click();
		assertTrue(zgradaCreationPage.getProzorDodavanjeZgrade().isDisplayed());
		zgradaCreationPage.getMesto().isDisplayed();
		zgradaCreationPage.getUlica().isDisplayed();
		zgradaCreationPage.getBroj().isDisplayed();
		zgradaCreationPage.getBrojStanova().isDisplayed();
		zgradaCreationPage.getSubmitDodajteBtn().isDisplayed();
		zgradaCreationPage.getResetujteBtn().isDisplayed();
		
	}
	//Pozitivan test, dodavanje zgrade
	
	@Test(priority=1)
	public void dodajZgradu(){
		zgradaCreationPage.createZgrada("Novi Sad", "Merime Meric", "5", "10");
		zgradaCreationPage.getSuccesMessage();
		assertTrue(zgradaCreationPage.getSuccesMessage().isDisplayed());
	}
	//pozitivan test, provera dodate zgrade
	@Test(priority=2)
	public void proveraDodateZgrade(){
		zgradaCreationPage.getPregledBtn().click();
		assertTrue(zgradaPregledPage.getTabelaPregledZgrada().isDisplayed());
		zgradaPregledPage.getRedZaPretragu().isDisplayed();
		assertTrue(zgradaPregledPage.getSelectPrikazi().isDisplayed());
		//assertTrue(zgradaPregledPage.getPrikaz().isMultiple());
		zgradaPregledPage.getPrikaz().selectByValue("5");
		zgradaPregledPage.getPrikaz().selectByValue("10");
		zgradaPregledPage.getPrikaz().selectByValue("25");
		zgradaPregledPage.getPrikaz().selectByValue("50");
		zgradaPregledPage.isZgradaInTabela("Merime Meric 5, Novi Sad");
//		WebElement zgradaRed = zgradaPregledPage.getZgradaRedByAdresa("Merime Meric 5, Novi Sad");
//		String pregledRed = zgradaRed.getText();
//		assertTrue(pregledRed.contains("Merime Meric 5, Novi Sad"));
	}
	@Test(priority=3)
	public void klikNaZgradaUTabeli(){
		zgradaPregledPage.viewZgradaByAdresa("Merime Meric 5, Novi Sad");
		zgradaPregledPage.getHoverTabelaZgrada().isDisplayed();
		zgradaPregledPage.viewVlasnikStanaZgrade("2");
		assertTrue(zgradaPregledPage.getTabelaKorisnici().isDisplayed());
	}
	@Test(priority=4)
	public void postaviKorisnikaZaStanara(){
		zgradaPregledPage.pritisniDodajUstanareBtn("Marko Markovic");
		assertEquals(zgradaPregledPage.getPorukaDodatStanarUstan().getText(),"Uspesno ste dodali stanara!");
	}
	@Test(priority=5)
		public void postaviStanaraZaVlasnika(){
		zgradaPregledPage.getTabelaStanari().isDisplayed();
		zgradaPregledPage.pritisniPostaviZaVlasnikaBtn("Marko Markovic");
		assertTrue(zgradaPregledPage.getPorukaUspesnoPostavljenVlasnik().isDisplayed());
			
		}
	@Test(priority=6)
	public void postaviPredsednika(){
		zgradaPregledPage.pritisniPostaviZaPredsednikaBtn("Marko Markovic");
		assertEquals(zgradaPregledPage.getPorukaUspesnoPostavljenPredsednik().getText(),"Uspesno ste postavili predsednika zgrade!");
	}
	
	@Test(priority=7)
	public void ukloniVlasnikaStana(){
		zgradaPregledPage.getUkloniVlasnikaBtn().isDisplayed();
		assertEquals(zgradaPregledPage.getPorukaUklonjenVlasnik().getText(),"Uspesno ste uklonili vlasnika!");
		
	}
	
	
	 
	
	//@AfterTest
	public void logout(){
		menuPageKTS.getIzlogujteSeBtn().click();
		
	}
	
	
	@AfterSuite
	
	public void closeSelenium() {
		logout();
		driver.quit();
	}


}
