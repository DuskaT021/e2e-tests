package rs.ac.uns.testdevelopment.KTS.pages.stanari;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class StanariPregledPage {
	private WebDriver driver;

	public StanariPregledPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getRedZaPretragu(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@class='row']"), 20);
	}
	
	public WebElement getPregledBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button/b[contains(text(),'Pregled')]"), 20);
	}
	public WebElement getPretragaBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button[contains(text(),'Pretraga')]"), 20);
	}
	
	
	public Select getPrikaz(){
		WebElement el = driver.findElement(By.id("prikaz"));
		Select dropdown = new Select(el);
		return dropdown;
	}
	public WebElement getSelectPrikazi(){
		return Utils.waitForElementPresence(driver, By.id("prikaz"), 20);
	}
	public WebElement getInputUnesite(){
		return Utils.waitForElementPresence(driver, By.id("filter"), 20);
	}
	public void setInputUnesite(String value){
		WebElement el = this.getInputUnesite();
		el.clear();
		el.sendKeys(value);
		}
	public void pretragaStanara(String imePrezime){
		setInputUnesite(imePrezime);
		getPretragaBtn().click();
		
	}
	public WebElement getVlasnikStanariBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//a[contains(text(),'Vlasnik i stanari')]"), 20);
	}
	public WebElement getNePostojiStanarPoruka(){
		return Utils.waitForElementPresence(driver, By.tagName("h2"), 20);
	}
	
	public WebElement getTabelaStanariPregled(){
		return Utils.waitForElementPresence(driver,By.tagName("table"),20);
	}
	public List<WebElement> getTabelaRedovi() {
		return this.getTabelaStanariPregled().findElements(By.tagName("tr"));
	}
	public boolean isStanarInTabela(String imePrezime) {
		return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + imePrezime + "\")]/../.."));
	}
	public WebElement getStanarRedByImePrezime(String imePrezime){
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + imePrezime + "\")]/../.."), 10);	
	}
	public void viewStanarByImePrezime(String imePrezime){
		getStanarRedByImePrezime(imePrezime).findElement(By.tagName("a")).click();
	}
	
	

}
