package rs.ac.uns.testdevelopment.KTS.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class MenuPageKTS {

	WebDriver driver;

	public MenuPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}

	
	

	public WebElement getPregledDugme(){
		return Utils.waitForElementPresence(driver, By.xpath("//button/b[contains(text(),\"Pregled\")]"), 20);
	}
	
	public WebElement getDodavanjeDugme(){
		return Utils.waitForElementPresence(driver, By.xpath("//button/b[contains(text(),\"Dodavanje\")]"), 20);
	}
	public WebElement getNavBar() {
		return Utils.waitForElementPresence(driver, By.tagName("nav"), 50);
	}

	public WebElement getPocetna() {
		return Utils.waitForElementPresence(driver, By.linkText("Pocetna"), 10);
	}

	public WebElement getZgrade() {
		return Utils.waitForElementPresence(driver, By.linkText("Zgrade"), 50);
	}

	public WebElement getStanari() {
		return Utils.waitForElementPresence(driver, By.linkText("Stanari"), 50);
	}
	public WebElement getInstitucije(){
		return Utils.waitForElementPresence(driver, By.xpath("//h4/ul/li/a[@href='/institucije']"), 20);
	}
	public WebElement getRegistrujteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button[@type='submit']"), 20);
	}

	public WebElement getLabelMail() {
		return Utils.waitForElementPresence(driver, By.xpath("//label[@class=\"nav-link active\"]"), 10);
	}

	public WebElement getIzlogujteSeBtn() {
		return Utils.waitForElementPresence(driver, By.className("btn-secondary"), 10);
	}
}
