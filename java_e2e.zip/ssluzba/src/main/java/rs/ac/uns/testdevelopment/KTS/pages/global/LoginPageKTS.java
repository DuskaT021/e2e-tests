package rs.ac.uns.testdevelopment.KTS.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class LoginPageKTS {
	private WebDriver driver;

	public LoginPageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getEmail (){
		return Utils.waitForElementPresence(driver, By.id("email"), 10);
	}
	
	
	
	public void setEmail (String email) {
		WebElement emailInput = getEmail();
		emailInput.clear();
		emailInput.sendKeys(email);
		
	}
	public WebElement getLozinka (){
		return Utils.waitForElementPresence(driver, By.id("lozinka"), 10);

}
	
	public void setLozinka (String lozinka) {
		WebElement lozinkaInput = getLozinka();
		lozinkaInput.clear();
		lozinkaInput.sendKeys(lozinka);
	
}
	
public WebElement getUlogujteSeBtn () {
	return Utils.waitForElementPresence(driver, By.className("btn-primary"), 10);
}
 public WebElement getLoginForm (){
	 return Utils.waitForElementPresence(driver, By.name("loginForm"),10);
 }
 


public void login(String email, String lozinka) {
	setEmail(email);
	setLozinka(lozinka);
	getUlogujteSeBtn().click();
	
}

public void navigateToPage(){
	driver.navigate().to("http://localhost:8080/logovanje");

}


}























