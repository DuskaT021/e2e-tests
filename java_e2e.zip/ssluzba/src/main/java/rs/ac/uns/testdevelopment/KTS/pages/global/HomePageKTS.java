package rs.ac.uns.testdevelopment.KTS.pages.global;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class HomePageKTS {
	private WebDriver driver;

	public HomePageKTS(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getOpcijeForm(WebDriver driver){
		return Utils.waitForElementPresence(driver, By.xpath("//form[@name=\"loginForm\"]"), 10);
	}
	//poruka o neuspesnom logovanju
	public String getNeuspesnoLogovanje() {
		return Utils.waitForElementPresence(driver, By.className("alert-dismissible"), 10).getText();

}}
