package rs.ac.uns.testdevelopment.KTS.pages.institucije;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class InstitucijaPregledPage {
	private WebDriver driver;

	public InstitucijaPregledPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public Select getPrikaz() {
		WebElement el = driver.findElement(By.id("prikaz"));
		Select dropdown = new Select(el);
		return dropdown;
	}

	public void setPrikaz(String pr) {
		Select prikaz = this.getPrikaz();
		prikaz.selectByValue(pr);
	}
	public WebElement getInstitucijaPregledZgrada() {
		return Utils.waitForElementPresence(driver, By.tagName("table"), 20);
	}
	public List<WebElement> getTabelaRedovi() {
		return this.getInstitucijaPregledZgrada().findElements(By.tagName("tr"));
	}
	public WebElement getInstitucijaRedByEmail(String email) {
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + email + "\")]/../.."), 20);

	}
	public void viewInstitucijaByEmail(String email) {
		getInstitucijaRedByEmail(email).findElement(By.tagName("tr")).getText();
	}
}
