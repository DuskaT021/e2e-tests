package rs.ac.uns.testdevelopment.KTS.pages.zgrade;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class ZgradaPregledPage {
	private WebDriver driver;

	public ZgradaPregledPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getRedZaPretragu() {
		return Utils.waitForElementPresence(driver, By.xpath("//div[@class='row']"), 20);
	}

	public Select getPrikaz() {
		WebElement el = driver.findElement(By.id("prikaz"));
		Select dropdown = new Select(el);
		return dropdown;
	}

	public void setPrikaz(String pr) {
		Select prikaz = this.getPrikaz();
		prikaz.selectByValue(pr);
	}

	public WebElement getSelectPrikazi() {
		return Utils.waitForElementPresence(driver, By.id("prikaz"), 20);
	}

	public WebElement getVlasnikStanariBtn() {
		return Utils.waitForElementPresence(driver, By.xpath("//a[contains(text(),'Vlasnik i stanari')]"), 20);
	}

	public WebElement getInputUlicaBroj() {
		return Utils.waitForElementPresence(driver, By.id("ulicaBroj"), 20);
	}

	public void setInputUlicaBroj(String value) {
		WebElement el = this.getInputUlicaBroj();
		el.clear();
		el.sendKeys(value);
	}

	public WebElement getInputMesto() {
		return Utils.waitForElementPresence(driver, By.id("mesto"), 20);
	}

	public void setInputMesto(String value) {
		WebElement el = this.getInputMesto();
		el.clear();
		el.sendKeys(value);
	}

	public void pretragaZgrade(String ulicaBroj, String mesto) {
		setInputUlicaBroj(ulicaBroj);
		setInputMesto(mesto);
		getPretragaBtn().click();
	}

	public WebElement getPretragaBtn() {
		return Utils.waitForElementPresence(driver, By.xpath("//button[contains(text(),'Pretraga')]"), 30);
	}

	public WebElement getNePostojiZgradaPoruka() {
		return Utils.waitForElementPresence(driver, By.tagName("h2"), 40);
	}

	public WebElement getTabelaPregledZgrada() {
		return Utils.waitForElementPresence(driver, By.tagName("table"), 20);
	}

	public List<WebElement> getTabelaRedovi() {
		return this.getTabelaPregledZgrada().findElements(By.tagName("tr"));
	}

	public boolean isZgradaInTabela(String adresa) {
		return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + adresa + "\")]/../.."));
	}

	public WebElement getZgradaRedByAdresa(String adresa) {
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + adresa + "\")]/../.."), 20);

	}

	public void viewZgradaByAdresa(String adresa) {
		getZgradaRedByAdresa(adresa).findElement(By.tagName("a")).click();
	}

	public WebElement getVlasnikaStanaZgrade(String vlasnik) {
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + vlasnik + "\")]/../.."), 20);

	}

	public void viewVlasnikStanaZgrade(String vlasnik) {
		getVlasnikaStanaZgrade(vlasnik).findElement(By.linkText("Vlasnik i stanari")).click();
	}

	public WebElement getHoverTabelaZgrada() {
		return Utils.waitForElementPresence(driver, By.xpath("//*[@class='table table-hover']"), 20);
	}

	public WebElement getTabelaKorisnici() {
		return Utils.waitForElementPresence(driver, By.id("korisnici"), 40);
	}

	public WebElement getRowKorisniciByStanar(String korisnik) {
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + korisnik + "\")]/../.."), 20);

	}

	public void pritisniDodajUstanareBtn(String korisnik) {
		getRowKorisniciByStanar(korisnik).findElement(By.xpath("//button[contains(text(),'Dodaj u stanare')]")).click();
	}

	public WebElement getPorukaDodatStanarUstan() {
		return Utils.waitForElementPresence(driver, By.xpath("//*[@aria-label='Uspesno ste dodali stanara!']"), 20);
	}

	public WebElement getTabelaStanari() {
		return Utils.waitForElementPresence(driver, By.id("stanari"), 20);
	}

	public WebElement getRowVlasniciStanari(String stanar) {
		return Utils.waitForElementPresence(driver, By.tagName("tr"), 20);
	}

	public void pritisniPostaviZaVlasnikaBtn(String stanar) {
		getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Postavi za vlasnika')]")).click();
	}
	public void ukloniStanaraBtn(String stanar){
		getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Ukloni')]")).click();
	}

	public WebElement getPorukaUspesnoPostavljenVlasnik() {
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste postavili vlasnika!']"),
				20);
	}

	public WebElement getUkloniVlasnikaBtn() {
		return Utils.waitForElementPresence(driver, By.id("ukloniVlasnika"), 40);
	}

	public WebElement getPorukaUklonjenVlasnik() {
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste uklonili vlasnika!']"),
				20);
	}
	
	public WebElement getPorukaUklonjenStanar(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste uklonili stanara!']"), 20);
	}
	public void pritisniPostaviZaPredsednikaBtn(String stanar){
		getRowVlasniciStanari(stanar).findElement(By.xpath("//button[contains(text(),'Postavi za predsednika')]")).click();
	}
	public WebElement getPostaviZaPredsednikaBtn(){
		return Utils.waitToBeClickable(driver, By.xpath("//button[contains(text(),'Postavi za predsednika')]"), 10);
	}
	
	public WebElement getPorukaUspesnoPostavljenPredsednik(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label='Uspesno ste postavili predsednika zgrade!']"), 20);
	}

}
