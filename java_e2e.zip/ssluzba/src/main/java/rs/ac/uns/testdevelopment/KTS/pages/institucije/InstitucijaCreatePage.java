package rs.ac.uns.testdevelopment.KTS.pages.institucije;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class InstitucijaCreatePage {
	private WebDriver driver;

	public InstitucijaCreatePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getRegistrujteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button[@type='submit']"), 20);
		}
	public WebElement getResetujteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//button[@type='button']"), 20);
	}
	public WebElement getPorukaUspesnoRegistrovanje(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label]"), 20);
	}
	public WebElement getRegistrationForm(){
		return Utils.waitForElementPresence(driver, By.xpath("//form"), 20);
	}
	public WebElement getEmail(){
		return Utils.waitForElementPresence(driver, By.id("email"), 20);
	}
	public void setEmail(String value){
		WebElement el = this.getEmail();
		el.clear();
		el.sendKeys(value);
	}
	public WebElement getLozinka(){
		return Utils.waitForElementPresence(driver, By.id("lozinka"), 20);
	}
	public void setLozinka(String value){
		WebElement el = this.getLozinka();
		el.clear();
		el.sendKeys(value);
	}
	public WebElement getNaziv(){
		return Utils.waitForElementPresence(driver, By.id("naziv"), 20);
	}
	public void setNaziv(String value){
		WebElement el = this.getNaziv();
		el.clear();
		el.sendKeys(value);
	}
	public WebElement getMesto(){
		return Utils.waitForElementPresence(driver, By.id("mesto"), 20);
	}
	public void setMesto(String value){
		WebElement el = this.getMesto();
		el.clear();
		el.sendKeys(value);
		}
	public WebElement getUlica(){
		return Utils.waitForElementPresence(driver, By.id("ulica"), 20);
	}
	public void setUlica(String value){
		WebElement el = this.getUlica();
		el.clear();
		el.sendKeys(value);
		}
	public WebElement getBroj(){
		return Utils.waitForElementPresence(driver, By.id("broj"), 20);
	}
	public void setBroj(String value){
		WebElement el = this.getBroj();
		el.clear();
		el.sendKeys(value);
	}
	public WebElement getBrojTelefona(){
		return Utils.waitForElementPresence(driver, By.id("brojTelefona"), 20);
		
	}
	public void setBrojTelefona(String value){
		WebElement el = this.getBrojTelefona();
		el.clear();
		el.sendKeys(value);
		}
	
	public void createInstitucija(String email, String lozinka, String naziv, String mesto, String ulica, String broj, String brojTelefona  ){
		setEmail(email);
		setLozinka(lozinka);
		setNaziv(naziv);
		setMesto(mesto);
		setUlica(ulica);
		setBroj(broj);
		setBrojTelefona(brojTelefona);
	}
		
	
}
