package rs.ac.uns.testdevelopment.KTS.pages.stanari;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class StanariCreatePage {
	private WebDriver driver;

	public StanariCreatePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	 public WebElement getFormRegistracijaStanara(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/form"), 20);
	 }
	  
	 public WebElement getEmailPolje(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/input[@id=\"email\"]"), 50);
	 }
	 public void setEmailPolje(String value){
		 WebElement el =this.getEmailPolje();
		 el.clear();
		 el.sendKeys(value);
	 }
	 public WebElement getLozinkaPolje(){
		 return Utils.waitForElementPresence(driver, By.xpath("//input[@id=\"lozinka\"]"), 20);
	 }
	 public void setLozinkaPolje(String value){
		 WebElement el =this.getLozinkaPolje();
		 el.clear();
		 el.sendKeys(value);
	 }
	 
	 public WebElement getImePolje(){
		 return Utils.waitForElementPresence(driver, By.xpath("//input[@id=\"ime\"]"), 20);
		}
	 public void setImePolje(String value){
		 WebElement el = this.getImePolje();
		 el.clear();
		 el.sendKeys(value);
	 }
	 
	 public WebElement getPrezimePolje(){
		 return Utils.waitForElementPresence(driver, By.xpath("//input[@id=\"prezime\"]"), 20);
	 }
	 public void setPrezimePolje(String value){
		 WebElement el = this.getPrezimePolje();
		 el.clear();
		 el.sendKeys(value);
	 }
	 public void createStanari(String email, String lozinka, String ime, String prezime ){
		 setEmailPolje(email);
		 setLozinkaPolje(lozinka);
		 setImePolje(ime);
		 setPrezimePolje(prezime);
		 
	 }
	 public WebElement getRegistrujteBtn(){
		 return Utils.waitForElementPresence(driver, By.xpath("//button[contains(text(),'Registrujte')]"), 20);
	 }
	 public WebElement getDisabledRegistrujteBtn(){
		 return Utils.waitForElementPresence(driver, By.xpath("*//div/div/button[@disabled]"), 20);
	 }
	 public WebElement getResetujteBtn(){
		 return Utils.waitToBeClickable(driver, By.xpath("//button[contains(text(),'Resetujte')]"), 20);
	 }
	 public WebElement getUspesnaRegistracijaPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[@role='alertdialog']"), 10);
		 
	 }
	 public WebElement getZauzetEmailPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-live=\"polite\"]"), 20);
	 }
	 public WebElement getPraznoEmailPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 20);
	 }
	 public WebElement getPraznoLozinkaPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 20);
	 }
	 public WebElement getPraznoImePoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[3]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 20);
	 }
	 public WebElement getPraznoPrezimePoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div[4]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 70);
	 }
	 public WebElement getNeispravanEmailPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//form//div[contains(text(),'Neispravna email adresa!')]"), 20);
	 }
	 public WebElement getNeispravnaLozinkaPoruka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//form//div[contains(text(),'Neispravna lozinka!')]"), 20);
	 }
	 
	 public WebElement getLabelEmail(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/label[@for='email']"),10);
	 }
	 public WebElement getLabelLozinka(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/label[@for='lozinka']"), 10);
		 
	 }
	 public WebElement getLabelIme(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/label[@for='ime']"), 10);
	 }
	 public WebElement getLabelPrezime(){
		 return Utils.waitForElementPresence(driver, By.xpath("//div/label[@for='prezime']"), 10);
	 }
	 

}
