package rs.ac.uns.testdevelopment.KTS.pages.zgrade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import rs.ac.uns.testdevelopment.ssluzba.helpers.Utils;

public class ZgradaCreationPage {
	private WebDriver driver;

	public ZgradaCreationPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	
	public WebElement getProzorDodavanjeZgrade(){
		return Utils.waitForElementPresence(driver,By.xpath("//div[@class=\"container\"]//form[@class=\"col-md-6 box ng-untouched ng-pristine ng-invalid\"]"), 0);
	}
	
	public WebElement getDodavanjeBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//div/ul/li/button[@class=\"btn btn-primary\"]"), 10);
	}
	
	public WebElement getPregledBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//div/ul/li/button[@class=\"btn btn-outline-primary\"]"), 10);
	}
	
	public WebElement getMesto(){
		return Utils.waitForElementPresence(driver, By.id("mesto"), 20);
	}
	
	public void setMesto(String value){
		WebElement el = this.getMesto();
		el.clear();
		el.sendKeys(value);
	}
	
	public WebElement getUlica(){
		return Utils.waitForElementPresence(driver, By.id("ulica"), 20);
	}
	
	public void setUlica(String value){
		WebElement el = this.getUlica();
		el.clear();
		el.sendKeys(value);
	}
	
	public WebElement getBroj(){
		return Utils.waitForElementPresence(driver, By.id("broj"), 20);
		
	}
	public void setBroj(String value){
		WebElement el = this.getBroj();
		el.clear();
		el.sendKeys(value);
	}
	
	public WebElement getBrojStanova(){
		return Utils.waitForElementPresence(driver, By.id("brojStanova"), 20);
	}
	public void setBrojStanova(String value){
		WebElement el = this.getBrojStanova();
		el.clear();
		el.sendKeys(value);
	}
	
	public WebElement getSubmitDodajteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//div//button[@type=\"submit\"]"), 10);
	}
	
	public WebElement getDisabledDodajteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//div//button[contains(text(),'Dodajte')]"), 20);
	}
	
	public WebElement getResetujteBtn(){
		return Utils.waitForElementPresence(driver, By.xpath("//div/button[@type=\"button\"]"), 10);
	}
	public WebElement getSuccesMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label=\"Uspesno ste dodali zgradu!\"]"),30);
		
	}
	public WebElement getVecPostojiMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@aria-label]"),10);
	}
	
	public WebElement getEmptyMestoMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[1]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 50);
	}
	public WebElement getEmptyUlicaMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[2]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 50);
	}
	public WebElement getEmptyBrojMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[3]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 50);
	}
	public WebElement getEmptyBrojStanovaMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[4]/div/div[contains(text(),'Ovo polje ne sme biti prazno!')]"), 70);
	}
	public WebElement getNulaBrojMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[3]/div/div[contains(text(),'Broj mora biti pozitivan!')]"), 20);
	}
	public WebElement getNulaBrojStanovaMessage(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[4]/div/div[contains(text(),'Broj mora biti pozitivan!')]"), 20);
	}
	
	
	public void createZgrada(String mesto, String ulica, String broj, String brojStanova){
		setMesto(mesto);
		setUlica(ulica);
		setBroj(broj);
		setBrojStanova(brojStanova);
		getSubmitDodajteBtn().click();
	}
	public void createPraznaZgrada(String mesto, String ulica, String broj, String brojStanova){
		setMesto(mesto);
		setUlica(ulica);
		setBroj(broj);
		setBrojStanova(brojStanova);
		
	}
}

